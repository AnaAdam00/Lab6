package services;

public interface Visitee {
    void accept(Visitor visitor);
}